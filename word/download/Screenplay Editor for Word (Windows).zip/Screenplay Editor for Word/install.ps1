# Screenplay Editor for Word — Windows install (per user, no admin).
# Puts the template where Word loads it at start, and registers the add-in
# manifest so Word shows the ribbon group and the pane.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$startup = Join-Path $env:APPDATA 'Microsoft\Word\STARTUP'
$dest = Join-Path $env:LOCALAPPDATA 'Screenplay Editor'
New-Item -ItemType Directory -Force -Path $startup, $dest | Out-Null
Copy-Item (Join-Path $here 'Screenplay Editor.dotm') (Join-Path $startup 'Screenplay Editor.dotm') -Force
Copy-Item (Join-Path $here 'manifest.xml') (Join-Path $dest 'manifest.xml') -Force
$key = 'HKCU:\Software\Microsoft\Office\16.0\WEF\Developer'
New-Item -Path $key -Force | Out-Null
New-ItemProperty -Path $key -Name 'ScreenplayEditor' -Value (Join-Path $dest 'manifest.xml') -PropertyType String -Force | Out-Null
Write-Host ''
Write-Host 'Screenplay Editor for Word is installed.'
Write-Host 'Close Word if it is open, then open it again: the Screenplay group is in the Home tab.'
