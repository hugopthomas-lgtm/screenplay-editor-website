# Screenplay Editor for Word — Windows uninstall (per user).
$ErrorActionPreference = 'SilentlyContinue'
Remove-Item (Join-Path $env:APPDATA 'Microsoft\Word\STARTUP\Screenplay Editor.dotm') -Force
Remove-Item (Join-Path $env:LOCALAPPDATA 'Screenplay Editor') -Recurse -Force
Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\WEF\Developer' -Name 'ScreenplayEditor' -Force
Write-Host 'Screenplay Editor for Word is removed. Open Word again.'
